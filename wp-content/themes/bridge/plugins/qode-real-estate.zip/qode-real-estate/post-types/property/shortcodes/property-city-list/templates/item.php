<article class="qodef-pcl-item qode-item-space">
    <div class="qodef-pcl-item-inner">
        <?php echo qodef_re_get_cpt_shortcode_module_template_part( 'property', 'property-city-list', 'layout-collections/' . $item_layout, '', $params, $additional_params ); ?>
        <a itemprop="url" class="qodef-pcl-item-link qodef-block-drag-link" href="<?php echo esc_url($link); ?>" target="_self"></a>
    </div>
</article>