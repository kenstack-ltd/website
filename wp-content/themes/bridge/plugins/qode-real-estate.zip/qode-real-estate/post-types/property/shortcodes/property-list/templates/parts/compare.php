<?php if (isset($enable_compare) && $enable_compare == 'yes') { ?>
    <div class="qodef-item-compare">
        <?php echo qodef_re_get_add_to_compare_list_button(); ?>
    </div>
<?php } ?>